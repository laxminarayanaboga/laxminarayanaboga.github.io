from date_utilities import get_current_epoch_timestamp, get_today_9am_ist_epoch_timestamp
from fyers_session_management import get_fyers_session

import pandas as pd
import numpy as np
import time

from purchase_management import place_order


fyers = get_fyers_session()


# Parameters
symbols = ["NSE:SBIN-EQ", "NSE:RELIANCE-EQ"]  # List of symbols to trade
interval = "5"  # Candle interval
short_window = 10  # Short moving average period
long_window = 50  # Long moving average period
qty = 10  # Quantity for each trade
stop_loss_percent = 0.5  # Stop-loss in %
take_profit_percent = 1.0  # Take-profit in %


def fetch_historical_data(symbol, interval, range_from, range_to):
    # Prepare request data
    data = {
        "symbol": symbol,
        "resolution": interval,
        "date_format": "0",
        "range_from": range_from,  # Unix timestamp for the start date
        "range_to": range_to,      # Unix timestamp for the end date
        "cont_flag": "1"
    }
    response = fyers.history(data)
    print(response)

    # Check for errors in the response
    if response.get('s') != 'ok':
        print(f"Error fetching data for {symbol}: {response.get('message', 'Unknown error')}")
        return None

    # Parse response into a DataFrame
    candles = response.get('candles', [])
    df = pd.DataFrame(candles, columns=[
                      "timestamp", "open", "high", "low", "close", "volume"])

    # Convert timestamp to datetime for readability
    df['timestamp'] = pd.to_datetime(df['timestamp'], unit='s')
    df.set_index('timestamp', inplace=True)

    return df


def moving_average_crossover(symbol, interval, short_window, long_window, qty):
    # Fetch historical data
    df = fetch_historical_data(
        symbol, interval, get_today_9am_ist_epoch_timestamp(), get_current_epoch_timestamp())
    if df is None or df.empty:
        print(f"No data available for {symbol}")
        return  # Skip if data is unavailable

    # Calculate moving averages
    df['Short_MA'] = df['close'].rolling(window=short_window).mean()
    df['Long_MA'] = df['close'].rolling(window=long_window).mean()

    # Create Signal column: 1 for bullish crossover, 0 otherwise
    df['Signal'] = np.where(df['Short_MA'] > df['Long_MA'], 1, 0)

    # Create Position column: Signal changes (entry/exit points)
    df = df.assign(Position=df['Signal'].diff())

    # Handle NaN values in Position (fill NaNs in a single step)
    df['Position'] = df['Position'].fillna(0)

    # Example: Print the last few rows to verify calculations
    print(df.tail())

    # Ensure moving averages and signals are valid
    if df['Short_MA'].isna().all() or df['Long_MA'].isna().all():
        print(f"Not enough data to calculate moving averages for {symbol}")
        return

    # Track entry price for stop-loss and take-profit
    entry_price = None
    position = None  # Track if we have an open position ("BUY" or "SELL")

    for index, row in df.iterrows():
        # Entry logic
        if row['Position'] == 1 and position is None:  # Bullish crossover
            entry_price = row['close']
            # fyers.place_order(symbol=symbol, qty=qty,
            #                   type="BUY", product_type="INTRADAY")
            place_order(symbol, qty, "BUY", "INTRADAY")
            position = "BUY"
            # print(f"BUY order placed for {symbol} at {entry_price}")

        elif row['Position'] == -1 and position is None:  # Bearish crossover
            entry_price = row['close']
            # fyers.place_order(symbol=symbol, qty=qty,
            #                   type="SELL", product_type="INTRADAY")
            place_order(symbol, qty, "SELL", "INTRADAY")
            position = "SELL"
            # print(f"SELL order placed for {symbol} at {entry_price}")

        # Exit logic (stop-loss and take-profit)
        if position == "BUY" and entry_price is not None:
            # Stop-loss hit
            if row['close'] <= entry_price * (1 - stop_loss_percent / 100):
                # fyers.place_order(symbol=symbol, qty=qty,
                #                   type="SELL", product_type="INTRADAY")
                place_order(symbol, qty, "SELL", "INTRADAY")
                position = None
                entry_price = None
                # print(f"SELL (stop-loss) order placed for {symbol}")

            # Take-profit hit
            elif row['close'] >= entry_price * (1 + take_profit_percent / 100):
                # fyers.place_order(symbol=symbol, qty=qty,
                #                   type="SELL", product_type="INTRADAY")
                place_order(symbol, qty, "BUY", "INTRADAY")
                position = None
                entry_price = None
                # print(f"SELL (take-profit) order placed for {symbol}")

        elif position == "SELL" and entry_price is not None:
            # Stop-loss hit
            if row['close'] >= entry_price * (1 + stop_loss_percent / 100):
                # fyers.place_order(symbol=symbol, qty=qty,
                #                   type="BUY", product_type="INTRADAY")
                place_order(symbol, qty, "BUY", "INTRADAY")
                position = None
                entry_price = None
                # print(f"BUY (stop-loss) order placed for {symbol}")

            # Take-profit hit
            elif row['close'] <= entry_price * (1 - take_profit_percent / 100):
                # fyers.place_order(symbol=symbol, qty=qty,
                #                   type="BUY", product_type="INTRADAY")
                place_order(symbol, qty, "BUY", "INTRADAY")
                position = None
                entry_price = None
                # print(f"BUY (take-profit) order placed for {symbol}")


# data = fetch_historical_data(
#     "NSE:SBIN-EQ", interval, get_today_9am_ist_epoch_timestamp(), get_current_epoch_timestamp())
# print(data)

moving_average_crossover("NSE:SBIN-EQ", interval,
                         short_window, long_window, qty)
