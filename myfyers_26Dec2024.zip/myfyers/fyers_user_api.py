from fyers_session_management import get_fyers_session


fyers = get_fyers_session()


####################################################################################################################
"""
1. User Apis 
"""

print("======== Profile =======")
print(fyers.get_profile())

print("======== Funds =======")
print(fyers.funds())
