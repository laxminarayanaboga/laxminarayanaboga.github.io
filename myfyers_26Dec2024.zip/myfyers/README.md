# JAI SRI RAM 

# Fyers APIs Usage

## Generate access_token
- Run step1
- Run step2 --> extract the access_token from the redirected url and save it to config file.

## userApi
## transactionApi


