from fyers_apiv3 import fyersModel
import webbrowser

"""
In order to get started with Fyers API we would like you to do the following things first.
1. Checkout our API docs :   https://myapi.fyers.in/docsv3
2. Create an APP using our API dashboard :   https://myapi.fyers.in/dashboard/

Once you have created an APP you can start using the below SDK 
"""

#### Generate an authcode and then make a request to generate an accessToken (Login Flow)

"""
1. Input parameters
"""
redirect_uri= "http://127.0.0.1"  ## redircet_uri you entered while creating APP.
client_id = "FX2FWYFX33-100"                       ## Client_id here refers to APP_ID of the created app
secret_key = "JXK8R6Z976"                          ## app_secret key which you got after creating the app 
grant_type = "authorization_code"                  ## The grant_type always has to be "authorization_code"
response_type = "code"                             ## The response_type always has to be "code"
state = "sample"                                   ##  The state field here acts as a session manager. you will be sent with the state field after successfull generation of auth_code 


### Connect to the sessionModel object here with the required input parameters
appSession = fyersModel.SessionModel(client_id = client_id, redirect_uri = redirect_uri,response_type=response_type,state=state,secret_key=secret_key,grant_type=grant_type)

# ## Make  a request to generate_authcode object this will return a login url which you need to open in your browser from where you can get the generated auth_code 
generateTokenUrl = appSession.generate_authcode()

"""There are two method to get the Login url if  you are not automating the login flow
1. Just by printing the variable name 
2. There is a library named as webbrowser which will then open the url for you without the hasel of copy pasting
both the methods are mentioned below"""
# print((generateTokenUrl))  
# webbrowser.open(generateTokenUrl,new=1)

# http://127.0.0.1/?s=ok&code=200&auth_code=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJhcGkubG9naW4uZnllcnMuaW4iLCJpYXQiOjE3MzQ5NTQ1MDQsImV4cCI6MTczNDk4NDUwNCwibmJmIjoxNzM0OTUzOTA0LCJhdWQiOlsieDowIiwieDoxIiwieDoyIiwiZDoxIiwiZDoyIiwieDoxIiwieDowIl0sInN1YiI6ImF1dGhfY29kZSIsImRpc3BsYXlfbmFtZSI6IllCMDc5NTQiLCJvbXMiOiJLMSIsImhzbV9rZXkiOm51bGwsIm5vbmNlIjoiIiwiYXBwX2lkIjoiRlgyRldZRlgzMyIsInV1aWQiOiI4NzZjMmQzMDY2ODk0ODA1YjJmNTM4NGMwZDRmMWNhNiIsImlwQWRkciI6Ijg2LjMxLjI0MS40MSwgMTcyLjcxLjIwMi40Iiwic2NvcGUiOiIifQ.y6E2qP2nSKrbj2mKMcQxvAaYMhI4ov9BFyX2Pg3rKZE&state=sample

### After succesfull login the user can copy the generated auth_code over here and make the request to generate the accessToken 
# auth_code = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJhcGkubG9naW4uZnllcnMuaW4iLCJpYXQiOjE3MzQ5NTQ4MzcsImV4cCI6MTczNDk4NDgzNywibmJmIjoxNzM0OTU0MjM3LCJhdWQiOiJbXCJ4OjBcIiwgXCJ4OjFcIiwgXCJ4OjJcIiwgXCJkOjFcIiwgXCJkOjJcIiwgXCJ4OjFcIiwgXCJ4OjBcIl0iLCJzdWIiOiJhdXRoX2NvZGUiLCJkaXNwbGF5X25hbWUiOiJZQjA3OTU0Iiwib21zIjoiSzEiLCJoc21fa2V5IjoiNTBhNmE0YTVlY2ZhYmRjZWQ4Y2E4MWJhN2QzMmFiNTNiYzFjMGJkYzQ5OGViN2IxMzI0YzBlN2UiLCJub25jZSI6IiIsImFwcF9pZCI6IkZYMkZXWUZYMzMiLCJ1dWlkIjoiYzUxNDY2MzFlZGI0NDhmMjhlNTliYWQzZGQ3YmM4Y2EiLCJpcEFkZHIiOiIwLjAuMC4wIiwic2NvcGUiOiIifQ.FZYG1dZmVZNTJZSHffBi3rtZV2pLDng1uMLPyJ6ckWg"
# appSession.set_token(auth_code)
# response = appSession.generate_token()

# access_token = None

# ## There can be two cases over here you can successfully get the acccessToken over the request or you might get some error over here. so to avoid that have this in try except block
# try: 
#     access_token = response["access_token"]
# except Exception as e:
#     print(e,response)  ## This will help you in debugging then and there itself like what was the error and also you would be able to see the value you got in response variable. instead of getting key_error for unsuccessfull response.

# print(access_token)  ## This is the access_token which you can use to make further requests to the API

access_token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJhcGkuZnllcnMuaW4iLCJpYXQiOjE3MzQ5NTQ4OTksImV4cCI6MTczNTAwMDI1OSwibmJmIjoxNzM0OTU0ODk5LCJhdWQiOlsieDowIiwieDoxIiwieDoyIiwiZDoxIiwiZDoyIiwieDoxIiwieDowIl0sInN1YiI6ImFjY2Vzc190b2tlbiIsImF0X2hhc2giOiJnQUFBQUFCbmFVLVRJX0FVNzF5LWRvVVUzS1FHREdqR0xqdHhuMGYwNDJISTVBTnVwV29udGlfV1lhbWlMMDl5QXZCdy1IRURhdHJKSFhmbWJPcGxVOF9ZWEVzdFRZLUwzOElfTkVOOXJabTR2VFFEQWthMXlUND0iLCJkaXNwbGF5X25hbWUiOiJCT0dBIExBWE1JTkFSQVlBTkEiLCJvbXMiOiJLMSIsImhzbV9rZXkiOiI1MGE2YTRhNWVjZmFiZGNlZDhjYTgxYmE3ZDMyYWI1M2JjMWMwYmRjNDk4ZWI3YjEzMjRjMGU3ZSIsImZ5X2lkIjoiWUIwNzk1NCIsImFwcFR5cGUiOjEwMCwicG9hX2ZsYWciOiJOIn0.JP6-cwpJ3wuaJG4k8MCM2LTg6Sgu7hTTGTGAw5HO73w"

## Once you have generated accessToken now we can call multiple trading related or data related apis after that in order to do so we need to first initialize the fyerModel object with all the requried params.
"""
fyerModel object takes following values as arguments
1. accessToken : this is the one which you received from above 
2. client_id : this is basically the app_id for the particular app you logged into
"""
fyers = fyersModel.FyersModel(token=access_token,is_async=False,client_id=client_id,log_path="")


## After this point you can call the relevant apis and get started with

####################################################################################################################
"""
1. User Apis : This includes (Profile,Funds,Holdings)
"""

print(fyers.get_profile())  ## This will provide us with the user related data 

print(fyers.funds())        ## This will provide us with the funds the user has 

print(fyers.holdings())    ## This will provide the available holdings the user has 

########################################################################################################################

"""
2. Transaction Apis : This includes (Tradebook,Orderbook,Positions)
"""

print(fyers.tradebook())   ## This will provide all the trade related information 

print(fyers.orderbook())   ## This will provide the user with all the order realted information 

print(fyers.positions())   ## This will provide the user with all the positions the user has on his end 

