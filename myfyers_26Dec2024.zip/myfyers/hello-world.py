# hello world program in python

def hello_world():
    print("Hello, World!")

hello_world()