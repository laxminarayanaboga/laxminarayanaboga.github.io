import pandas as pd
import numpy as np
import time

from configparser import ConfigParser
from fyers_apiv3 import fyersModel


place_intraday_sell_bracket_order(data)

# read config.ini
config = ConfigParser()
config.read('config.ini')


# get the values from the config.ini
client_id = config.get('Fyers_APP', 'client_id')
access_token = config.get('Fyers_APP', 'access_token')

fyers = fyersModel.FyersModel(
    token=access_token, is_async=False, client_id=client_id, log_path="")

# Parameters
symbols = ["NSE:SBIN", "NSE:RELIANCE"]  # List of symbols to trade
interval = "5minute"  # Candle interval
short_window = 10  # Short moving average period
long_window = 50  # Long moving average period
qty = 10  # Quantity for each trade
stop_loss_percent = 0.5  # Stop-loss in %
take_profit_percent = 1.0  # Take-profit in %

# Fetch historical data from FYERS


def fetch_historical_data(symbol, interval, days):
    # Replace this with the FYERS API call to fetch historical data
    return fyers.get_historical_data(symbol=symbol, interval=interval, days=days)

# Moving Average Crossover Strategy


def moving_average_crossover(symbol, interval, short_window, long_window, qty):
    # Fetch historical data
    data = fetch_historical_data(symbol, interval, days=5)
    data['Short_MA'] = data['close'].rolling(window=short_window).mean()
    data['Long_MA'] = data['close'].rolling(window=long_window).mean()
    data['Signal'] = np.where(data['Short_MA'] > data['Long_MA'], 1, 0)
    data['Position'] = data['Signal'].diff()

    # Track entry price for stop-loss and take-profit
    entry_price = None
    position = None  # Track if we have an open position ("BUY" or "SELL")

    for index, row in data.iterrows():
        # Entry logic
        if row['Position'] == 1 and position is None:  # Bullish crossover
            entry_price = row['close']
            fyers.place_order(symbol=symbol, qty=qty,
                              type="BUY", product_type="INTRADAY")
            position = "BUY"
            print(f"BUY order placed for {symbol} at {entry_price}")

        elif row['Position'] == -1 and position is None:  # Bearish crossover
            entry_price = row['close']
            fyers.place_order(symbol=symbol, qty=qty,
                              type="SELL", product_type="INTRADAY")
            position = "SELL"
            print(f"SELL order placed for {symbol} at {entry_price}")

        # Exit logic (stop-loss and take-profit)
        if position == "BUY" and entry_price is not None:
            # Stop-loss hit
            if row['close'] <= entry_price * (1 - stop_loss_percent / 100):
                fyers.place_order(symbol=symbol, qty=qty,
                                  type="SELL", product_type="INTRADAY")
                position = None
                entry_price = None
                print(f"SELL (stop-loss) order placed for {symbol}")

            # Take-profit hit
            elif row['close'] >= entry_price * (1 + take_profit_percent / 100):
                fyers.place_order(symbol=symbol, qty=qty,
                                  type="SELL", product_type="INTRADAY")
                position = None
                entry_price = None
                print(f"SELL (take-profit) order placed for {symbol}")

        elif position == "SELL" and entry_price is not None:
            # Stop-loss hit
            if row['close'] >= entry_price * (1 + stop_loss_percent / 100):
                fyers.place_order(symbol=symbol, qty=qty,
                                  type="BUY", product_type="INTRADAY")
                position = None
                entry_price = None
                print(f"BUY (stop-loss) order placed for {symbol}")

            # Take-profit hit
            elif row['close'] <= entry_price * (1 - take_profit_percent / 100):
                fyers.place_order(symbol=symbol, qty=qty,
                                  type="BUY", product_type="INTRADAY")
                position = None
                entry_price = None
                print(f"BUY (take-profit) order placed for {symbol}")


# Continuous polling loop

def run_strategy():
    while True:
        for symbol in symbols:
            print(f"Running strategy for {symbol}...")
            moving_average_crossover(
                symbol, interval, short_window, long_window, qty)
        time.sleep(60)  # Poll every 1 minute


# Run the strategy
run_strategy()
