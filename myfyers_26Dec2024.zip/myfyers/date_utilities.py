from datetime import datetime, time, timedelta
import pytz

def get_today_9am_ist_epoch_timestamp():
    ist = pytz.timezone('Asia/Kolkata')
    today = datetime.now(ist).date()
    today_9am = datetime.combine(today, time(9, 0, 0))
    today_9am_ist = ist.localize(today_9am)
    timestamp = int(today_9am_ist.timestamp())
    print(f'Today 9 AM IST: {today_9am_ist}, epoch timestamp: {timestamp}')
    return timestamp

def get_current_epoch_timestamp():
    ist = pytz.timezone('Asia/Kolkata')
    now_ist = datetime.now(ist)
    timestamp = int(now_ist.timestamp())
    print(f'Current time in IST: {now_ist}, epoch timestamp: {timestamp}')
    return timestamp

# get the epoch timestamp for n days before 9 AM IST
def get_ndays_before_9am_ist_epoch_timestamp(number_of_days_before):
    ist = pytz.timezone('Asia/Kolkata')
    today = datetime.now(ist).date()
    n_days_before = today - timedelta(days=number_of_days_before)
    n_days_before_9am = datetime.combine(n_days_before, time(9, 0, 0))
    n_days_before_9am_ist = ist.localize(n_days_before_9am)
    timestamp = int(n_days_before_9am_ist.timestamp())
    print(f'{number_of_days_before} days before 9 AM IST: {n_days_before_9am_ist}, epoch timestamp: {timestamp}')
    return timestamp


# # Call the functions and print the results
# print(get_today_9am_ist_epoch_timestamp())
# print(get_current_epoch_timestamp())
# print(get_ndays_before_9am_ist_epoch_timestamp(5))
