#  read the Fyers_APP variables from the config.ini FileExistsError

from configparser import ConfigParser
from fyers_apiv3 import fyersModel
import webbrowser


# read config.ini
config = ConfigParser()
config.read('config.ini')


# get the values from the config.ini
redirect_uri = config.get('Fyers_APP', 'redirect_uri')
client_id = config.get('Fyers_APP', 'client_id')
secret_key = config.get('Fyers_APP', 'secret_key')
grant_type = config.get('Fyers_APP', 'grant_type')
response_type = config.get('Fyers_APP', 'response_type')
state = config.get('Fyers_APP', 'state')


# Connect to the sessionModel object here with the required input parameters
appSession = fyersModel.SessionModel(client_id=client_id, redirect_uri=redirect_uri,
                                     response_type=response_type, state=state, secret_key=secret_key, grant_type=grant_type)


def step1():

    # ## Make  a request to generate_authcode object this will return a login url which you need to open in your browser from where you can get the generated auth_code
    generateTokenUrl = appSession.generate_authcode()

    """ STEP 1 === There are two method to get the Login url if  you are not automating the login flow
    1. Just by printing the variable name 
    2. There is a library named as webbrowser which will then open the url for you without the hasel of copy pasting
    both the methods are mentioned below"""
    print((generateTokenUrl))
    webbrowser.open(generateTokenUrl, new=1)


def step2():
    # STEP 2 === After succesfull login the user can copy the generated auth_code over here and make the request to generate the accessToken
    auth_code = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJhcGkubG9naW4uZnllcnMuaW4iLCJpYXQiOjE3MzU2Mzc2MTcsImV4cCI6MTczNTY2NzYxNywibmJmIjoxNzM1NjM3MDE3LCJhdWQiOiJbXCJ4OjBcIiwgXCJ4OjFcIiwgXCJ4OjJcIiwgXCJkOjFcIiwgXCJkOjJcIiwgXCJ4OjFcIiwgXCJ4OjBcIl0iLCJzdWIiOiJhdXRoX2NvZGUiLCJkaXNwbGF5X25hbWUiOiJZQjA3OTU0Iiwib21zIjoiSzEiLCJoc21fa2V5IjoiNTBhNmE0YTVlY2ZhYmRjZWQ4Y2E4MWJhN2QzMmFiNTNiYzFjMGJkYzQ5OGViN2IxMzI0YzBlN2UiLCJub25jZSI6IiIsImFwcF9pZCI6IkZYMkZXWUZYMzMiLCJ1dWlkIjoiYmUwNzhkNjZlYWQ3NDk2MGE1ODIyNTNhMDM1MWM1ZDAiLCJpcEFkZHIiOiIwLjAuMC4wIiwic2NvcGUiOiIifQ.0PK9SXAoG-1oR0ClWKPZQG1keKQCvndoGI25p4UClJk"

    appSession.set_token(auth_code)
    response = appSession.generate_token()

    access_token = None

    # There can be two cases over here you can successfully get the acccessToken over the request or you might get some error over here. so to avoid that have this in try except block
    try:
        access_token = response["access_token"]
    except Exception as e:
        # This will help you in debugging then and there itself like what was the error and also you would be able to see the value you got in response variable. instead of getting key_error for unsuccessfull response.
        print(e, response)

    # This is the access_token which you can use to make further requests to the API
    print(access_token)


# step1()
step2()
