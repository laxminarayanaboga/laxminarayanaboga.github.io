from date_utilities import get_current_epoch_timestamp, get_epoch_timestamp_from_datetime_ist_string, get_ndays_before_9am_ist_epoch_timestamp, get_today_9am_ist_epoch_timestamp
from fyers_session_management import get_fyers_session

import pandas as pd
import numpy as np
import pytz

from fyers_purchase_management import place_intraday_buy_bracket_order, place_intraday_sell_bracket_order
from symbols_management import getNifty100Symbols


# Set display options to print all columns
pd.set_option('display.max_columns', None)

fyers = get_fyers_session()


# Parameters
symbols = getNifty100Symbols()  
interval = "10"  # Candle interval
short_window = 10  # Short moving average period
long_window = 50  # Long moving average period
qty = 10  # Quantity for each trade
stop_loss_percent = 0.5  # Stop-loss in %
take_profit_percent = 1.0  # Take-profit in %


def fetch_historical_data(symbol, interval, range_from, range_to):
    # Prepare request data
    data = {
        "symbol": symbol,
        "resolution": interval,
        "date_format": "0",
        "range_from": range_from,  # Unix timestamp for the start date
        "range_to": range_to,      # Unix timestamp for the end date
        "cont_flag": "1"
    }
    response = fyers.history(data)
    # print(f'raw data for {symbol}, time interval {interval}: {response}')

    # Check for errors in the response
    if response.get('s') != 'ok':
        print(f"Error fetching data for {symbol}: {
              response.get('message', 'Unknown error')}")
        print(f'response: {response}')
        return None

    # Parse response into a DataFrame
    candles = response.get('candles', [])
    df = pd.DataFrame(candles, columns=[
                      "timestamp", "open", "high", "low", "close", "volume"])

    # Convert timestamp to datetime for readability
    # df['timestamp'] = pd.to_datetime(df['timestamp'], unit='s')
    # df.set_index('timestamp', inplace=True)

    # Convert timestamp to datetime for readability
    df['timestamp'] = pd.to_datetime(df['timestamp'], unit='s')
    ist = pytz.timezone('Asia/Kolkata')
    df['timestamp'] = df['timestamp'].dt.tz_localize('UTC').dt.tz_convert(ist)
    df.set_index('timestamp', inplace=True)

    # print first row of the data, open, high, low, close, volume in different rows
    # print(f'first row, high: {df.iloc[0]["high"]}, low: {df.iloc[0]["low"]}, close: {
    #       df.iloc[0]["close"]}, volume: {df.iloc[0]["volume"]}')

    # print(f"Data for {symbol} fetched successfully.")
    # print(f'data: {df}')
    return df


def calculate_moving_averages(df, short_window, long_window):
    df['Short_MA'] = df['close'].ewm(span=short_window, adjust=False).mean()
    df['Long_MA'] = df['close'].ewm(span=long_window, adjust=False).mean()
    return df


def check_crossover(data):
    """
    Check for bullish or bearish crossover using three recent candles.
    """
    if len(data) < max(short_window, long_window):
        return "none"

    # Compare the last three rows of moving averages
    short_ma_2_prev = data['Short_MA'].iloc[-3]
    long_ma_2_prev = data['Long_MA'].iloc[-3]
    short_ma_prev = data['Short_MA'].iloc[-2]
    long_ma_prev = data['Long_MA'].iloc[-2]
    short_ma_curr = data['Short_MA'].iloc[-1]
    long_ma_curr = data['Long_MA'].iloc[-1]

    # print(f"short_ma_2_prev: {short_ma_2_prev:.2f}, long_ma_2_prev: {long_ma_2_prev:.2f}, short_ma_prev: {
    #       short_ma_prev:.2f}, long_ma_prev: {long_ma_prev:.2f}, short_ma_curr: {short_ma_curr:.2f}, long_ma_curr: {long_ma_curr:.2f}")

    # Check for bullish crossover
    if short_ma_2_prev <= long_ma_2_prev and short_ma_prev <= long_ma_prev and short_ma_curr > long_ma_curr:
        return "bullish"

    # Check for bearish crossover
    elif short_ma_2_prev >= long_ma_2_prev and short_ma_prev >= long_ma_prev and short_ma_curr < long_ma_curr:
        return "bearish"

    # No crossover
    return "none"


def execute_trade(symbol, signal, close_price):
    """
    Execute a trade based on the signal.
    """
    if signal == "bullish":
        stopLoss = close_price * (1 - stop_loss_percent / 100)
        takeProfit = close_price * (1 + take_profit_percent / 100)
        place_intraday_buy_bracket_order(symbol, qty, stopLoss, takeProfit)
        print(f"BUY order placed for {symbol} at {close_price}")
    elif signal == "bearish":
        stopLoss = close_price * (1 - stop_loss_percent / 100)
        takeProfit = close_price * (1 + take_profit_percent / 100)
        place_intraday_sell_bracket_order(symbol, qty, stopLoss, takeProfit)
        print(f"SELL order placed for {symbol} at {close_price}")


def moving_average_crossover(symbol, interval, range_from, range_to, short_window, long_window):
    df = fetch_historical_data(symbol, interval, range_from, range_to)
    if df is None or df.empty:
        print(f"No data available for {symbol}")
        return  # Skip if data is unavailable

    # Calculate moving averages
    df = calculate_moving_averages(df, short_window, long_window)
    
    signal = check_crossover(df)
    print(f"Signal for {symbol}: {signal}")

    if signal != "none":
        close_price = df['close'].iloc[0]
        execute_trade(symbol, signal, close_price)


# data = fetch_historical_data(
#     "NSE:SBIN-EQ", interval, get_ndays_before_9am_ist_epoch_timestamp(10), get_current_epoch_timestamp())
# print(data)
# moving_average_crossover("NSE:SBIN-EQ", interval,
#                          get_epoch_timestamp_from_datetime_ist_string(
#                              "2024-12-03 13:10:00"),
#                          get_epoch_timestamp_from_datetime_ist_string(
#                              "2024-12-11 12:56:00"),
#                          short_window, long_window)

for symbol in symbols:
    moving_average_crossover(symbol, interval,
                             get_ndays_before_9am_ist_epoch_timestamp(10),
                             get_current_epoch_timestamp(),
                            #  get_epoch_timestamp_from_datetime_ist_string("2024-12-30 10:20:00"),
                             short_window, long_window)
