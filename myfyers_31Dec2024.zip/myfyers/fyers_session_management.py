from configparser import ConfigParser
from fyers_apiv3 import fyersModel

from date_utilities import get_ndays_before_9am_ist_epoch_timestamp, get_today_9am_ist_epoch_timestamp, get_current_epoch_timestamp


# read config.ini
config = ConfigParser()
config.read('config.ini')

# get the values from the config.ini
client_id = config.get('Fyers_APP', 'client_id')
access_token = config.get('Fyers_APP', 'access_token')

def get_fyers_session():
    return fyersModel.FyersModel(
        token=access_token, is_async=False, client_id=client_id, log_path="")
