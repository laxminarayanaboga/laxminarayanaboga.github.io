from fyers_session_management import get_fyers_session


fyers = get_fyers_session()


########################################################################################################################

"""
2. Transaction Apis 
"""

print("======== Tradebook =======")
print(fyers.tradebook())

print("======== Orderbook =======")
print(fyers.orderbook())

print("======== Positions =======")
print(fyers.positions())

print("======== Holdings =======")
print(fyers.holdings())
