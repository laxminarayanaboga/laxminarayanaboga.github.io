from date_utilities import get_current_epoch_timestamp, get_ndays_before_9am_ist_epoch_timestamp, get_today_9am_ist_epoch_timestamp
from fyers_session_management import get_fyers_session

import pandas as pd
import numpy as np

from fyers_purchase_management import place_intraday_buy_bracket_order, place_intraday_sell_bracket_order


# Set display options to print all columns
pd.set_option('display.max_columns', None)

fyers = get_fyers_session()


# Parameters
symbols = ["NSE:SBIN-EQ", "NSE:RELIANCE-EQ"]  # List of symbols to trade
interval = "10"  # Candle interval
short_window = 10  # Short moving average period
long_window = 50  # Long moving average period
qty = 10  # Quantity for each trade
stop_loss_percent = 0.5  # Stop-loss in %
take_profit_percent = 1.0  # Take-profit in %


def fetch_historical_data(symbol, interval, range_from, range_to):
    # Prepare request data
    data = {
        "symbol": symbol,
        "resolution": interval,
        "date_format": "0",
        "range_from": range_from,  # Unix timestamp for the start date
        "range_to": range_to,      # Unix timestamp for the end date
        "cont_flag": "1"
    }
    response = fyers.history(data)
    # print(f'raw data for {symbol}, time interval {interval}: {response}')

    # Check for errors in the response
    if response.get('s') != 'ok':
        print(f"Error fetching data for {symbol}: {
              response.get('message', 'Unknown error')}")
        return None

    # Parse response into a DataFrame
    candles = response.get('candles', [])
    df = pd.DataFrame(candles, columns=[
                      "timestamp", "open", "high", "low", "close", "volume"])

    # Convert timestamp to datetime for readability
    df['timestamp'] = pd.to_datetime(df['timestamp'], unit='s')
    df.set_index('timestamp', inplace=True)

    # print first row of the data, open, high, low, close, volume in different rows
    # print(f'first row, high: {df.iloc[0]["high"]}, low: {df.iloc[0]["low"]}, close: {
    #       df.iloc[0]["close"]}, volume: {df.iloc[0]["volume"]}')

    # print(f"Data for {symbol} fetched successfully.")
    print(f'data: {df}')
    return df


def moving_average_crossover(symbol, interval, range_from, range_to, short_window, long_window, qty):
    # Fetch historical data
    df = fetch_historical_data(symbol, interval, range_from, range_to)
    if df is None or df.empty:
        print(f"No data available for {symbol}")
        return  # Skip if data is unavailable

    # Calculate moving averages
    df['Short_MA'] = df['close'].rolling(window=short_window).mean()
    df['Long_MA'] = df['close'].rolling(window=long_window).mean()

    # Create Signal column: 1 for bullish crossover, 0 otherwise
    df['Signal'] = np.where(df['Short_MA'] > df['Long_MA'], 1, 0)

    # Create Position column: Signal changes (entry/exit points)
    df = df.assign(Position=df['Signal'].diff())

    # Handle NaN values in Position (fill NaNs in a single step)
    df['Position'] = df['Position'].fillna(0)

    # Example: Print all the column data
    print(f"Data for {symbol} with moving averages and signals: ")
    print(df)

    # Ensure moving averages and signals are valid
    if df['Short_MA'].isna().all() or df['Long_MA'].isna().all():
        print(f"Not enough data to calculate moving averages for {symbol}")
        return

    for index, row in df.iterrows():
        # Entry logic
        if row['Position'] == 1 and position is None:  # Bullish crossover
            entry_price = row['close']
            stopLoss = entry_price * (1 - stop_loss_percent / 100)
            takeProfit = entry_price * (1 + take_profit_percent / 100)
            place_intraday_buy_bracket_order(symbol, qty, stopLoss, takeProfit)
            position = "BUY"
            print(f"BUY order placed for {symbol} at {entry_price}")

        elif row['Position'] == -1 and position is None:  # Bearish crossover
            entry_price = row['close']
            stopLoss = entry_price * (1 - stop_loss_percent / 100)
            takeProfit = entry_price * (1 + take_profit_percent / 100)
            place_intraday_sell_bracket_order(
                symbol, qty, stopLoss, takeProfit)
            position = "SELL"
            print(f"SELL order placed for {symbol} at {entry_price}")

        # Exit logic -- no need to code. the bracket order will take care of it.


# data = fetch_historical_data(
#     "NSE:SBIN-EQ", interval, get_ndays_before_9am_ist_epoch_timestamp(10), get_current_epoch_timestamp())
# print(data)
moving_average_crossover("NSE:SBIN-EQ", interval,
                         get_ndays_before_9am_ist_epoch_timestamp(10),
                         get_ndays_before_9am_ist_epoch_timestamp(0),
                         short_window, long_window, qty)
